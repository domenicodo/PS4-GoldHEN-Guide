If crashing on launch install .net framework (included in Dependencies folder)
If getting .DLL error install vs_redist (included in Dependencies folder)

Both files can be downloaded directly from Microsoft at:

https://www.microsoft.com/en-us/download/details.aspx?id=48130
https://go.microsoft.com/fwlink/?LinkId=746571

HASH INFO for Duxa's PS4 patch repackager 7.2.18.exe

If it does not match delete and download from GBAtemp thread.

CRC32: E782ADC6
MD5: D6F9C5D06E9C884A206404C77442000D
SHA-1: ECBFA2CFC5E2074CC625A5D1122F5666F055E7E1
