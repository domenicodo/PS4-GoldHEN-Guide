﻿namespace PS4OfflineAccountActivator
{
    partial class MainForm
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.btConnect = new System.Windows.Forms.Button();
            this.tbIPAddress = new System.Windows.Forms.TextBox();
            this.lbIPAddress = new System.Windows.Forms.Label();
            this.btGetUsers = new System.Windows.Forms.Button();
            this.blUsn1 = new System.Windows.Forms.Label();
            this.tbPSNId1 = new System.Windows.Forms.TextBox();
            this.btSetAccountId1 = new System.Windows.Forms.Button();
            this.lbUsername1 = new System.Windows.Forms.Label();
            this.lbUsername2 = new System.Windows.Forms.Label();
            this.blUsn2 = new System.Windows.Forms.Label();
            this.tbPSNId2 = new System.Windows.Forms.TextBox();
            this.btSetAccountId2 = new System.Windows.Forms.Button();
            this.lbUsername3 = new System.Windows.Forms.Label();
            this.blUsn3 = new System.Windows.Forms.Label();
            this.tbPSNId3 = new System.Windows.Forms.TextBox();
            this.btSetAccountId3 = new System.Windows.Forms.Button();
            this.lbUsername4 = new System.Windows.Forms.Label();
            this.blUsn4 = new System.Windows.Forms.Label();
            this.tbPSNId4 = new System.Windows.Forms.TextBox();
            this.btSetAccountId4 = new System.Windows.Forms.Button();
            this.lbUsername5 = new System.Windows.Forms.Label();
            this.blUsn5 = new System.Windows.Forms.Label();
            this.tbPSNId5 = new System.Windows.Forms.TextBox();
            this.btSetAccountId5 = new System.Windows.Forms.Button();
            this.lbUsername6 = new System.Windows.Forms.Label();
            this.blUsn6 = new System.Windows.Forms.Label();
            this.tbPSNId6 = new System.Windows.Forms.TextBox();
            this.btSetAccountId6 = new System.Windows.Forms.Button();
            this.lbUsername7 = new System.Windows.Forms.Label();
            this.blUsn7 = new System.Windows.Forms.Label();
            this.tbPSNId7 = new System.Windows.Forms.TextBox();
            this.btSetAccountId7 = new System.Windows.Forms.Button();
            this.lbUsername8 = new System.Windows.Forms.Label();
            this.blUsn8 = new System.Windows.Forms.Label();
            this.tbPSNId8 = new System.Windows.Forms.TextBox();
            this.btSetAccountId8 = new System.Windows.Forms.Button();
            this.lbUsername9 = new System.Windows.Forms.Label();
            this.blUsn9 = new System.Windows.Forms.Label();
            this.tbPSNId9 = new System.Windows.Forms.TextBox();
            this.btSetAccountId9 = new System.Windows.Forms.Button();
            this.lbUsername10 = new System.Windows.Forms.Label();
            this.blUsn10 = new System.Windows.Forms.Label();
            this.tbPSNId10 = new System.Windows.Forms.TextBox();
            this.btSetAccountId10 = new System.Windows.Forms.Button();
            this.lbUsername11 = new System.Windows.Forms.Label();
            this.blUsn11 = new System.Windows.Forms.Label();
            this.tbPSNId11 = new System.Windows.Forms.TextBox();
            this.btSetAccountId11 = new System.Windows.Forms.Button();
            this.lbUsername12 = new System.Windows.Forms.Label();
            this.blUsn12 = new System.Windows.Forms.Label();
            this.tbPSNId12 = new System.Windows.Forms.TextBox();
            this.btSetAccountId12 = new System.Windows.Forms.Button();
            this.lbUsername13 = new System.Windows.Forms.Label();
            this.blUsn13 = new System.Windows.Forms.Label();
            this.tbPSNId13 = new System.Windows.Forms.TextBox();
            this.btSetAccountId13 = new System.Windows.Forms.Button();
            this.lbUsername14 = new System.Windows.Forms.Label();
            this.blUsn14 = new System.Windows.Forms.Label();
            this.tbPSNId14 = new System.Windows.Forms.TextBox();
            this.btSetAccountId14 = new System.Windows.Forms.Button();
            this.lbUsername15 = new System.Windows.Forms.Label();
            this.blUsn15 = new System.Windows.Forms.Label();
            this.tbPSNId15 = new System.Windows.Forms.TextBox();
            this.btSetAccountId15 = new System.Windows.Forms.Button();
            this.lbUsername16 = new System.Windows.Forms.Label();
            this.blUsn16 = new System.Windows.Forms.Label();
            this.tbPSNId16 = new System.Windows.Forms.TextBox();
            this.btSetAccountId16 = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 609);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(860, 26);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(392, 20);
            this.toolStripStatusLabel1.Text = "Disconnected. Enter your PS4 IP address and click Connect";
            // 
            // btConnect
            // 
            this.btConnect.Location = new System.Drawing.Point(295, 25);
            this.btConnect.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btConnect.Name = "btConnect";
            this.btConnect.Size = new System.Drawing.Size(113, 28);
            this.btConnect.TabIndex = 1;
            this.btConnect.Text = "1. Connect";
            this.btConnect.UseVisualStyleBackColor = true;
            this.btConnect.Click += new System.EventHandler(this.btConnect_Click);
            // 
            // tbIPAddress
            // 
            this.tbIPAddress.Location = new System.Drawing.Point(132, 27);
            this.tbIPAddress.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbIPAddress.Name = "tbIPAddress";
            this.tbIPAddress.Size = new System.Drawing.Size(140, 22);
            this.tbIPAddress.TabIndex = 2;
            // 
            // lbIPAddress
            // 
            this.lbIPAddress.AutoSize = true;
            this.lbIPAddress.Location = new System.Drawing.Point(29, 31);
            this.lbIPAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbIPAddress.Name = "lbIPAddress";
            this.lbIPAddress.Size = new System.Drawing.Size(92, 17);
            this.lbIPAddress.TabIndex = 3;
            this.lbIPAddress.Text = "Your PS4 IP :";
            // 
            // btGetUsers
            // 
            this.btGetUsers.Enabled = false;
            this.btGetUsers.Location = new System.Drawing.Point(429, 25);
            this.btGetUsers.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btGetUsers.Name = "btGetUsers";
            this.btGetUsers.Size = new System.Drawing.Size(113, 28);
            this.btGetUsers.TabIndex = 4;
            this.btGetUsers.Text = "2. Get Users";
            this.btGetUsers.UseVisualStyleBackColor = true;
            this.btGetUsers.Click += new System.EventHandler(this.btGetUsers_Click);
            // 
            // blUsn1
            // 
            this.blUsn1.AutoSize = true;
            this.blUsn1.Location = new System.Drawing.Point(48, 78);
            this.blUsn1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn1.Name = "blUsn1";
            this.blUsn1.Size = new System.Drawing.Size(93, 17);
            this.blUsn1.TabIndex = 7;
            this.blUsn1.Text = "Username 1 :";
            // 
            // tbPSNId1
            // 
            this.tbPSNId1.Location = new System.Drawing.Point(341, 74);
            this.tbPSNId1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId1.Name = "tbPSNId1";
            this.tbPSNId1.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId1.TabIndex = 6;
            // 
            // btSetAccountId1
            // 
            this.btSetAccountId1.Enabled = false;
            this.btSetAccountId1.Location = new System.Drawing.Point(648, 71);
            this.btSetAccountId1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId1.Name = "btSetAccountId1";
            this.btSetAccountId1.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId1.TabIndex = 5;
            this.btSetAccountId1.Text = "3. Set Id && Activate";
            this.btSetAccountId1.UseVisualStyleBackColor = true;
            this.btSetAccountId1.Click += new System.EventHandler(this.btSetAccountId1_Click);
            // 
            // lbUsername1
            // 
            this.lbUsername1.Location = new System.Drawing.Point(149, 78);
            this.lbUsername1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername1.Name = "lbUsername1";
            this.lbUsername1.Size = new System.Drawing.Size(184, 16);
            this.lbUsername1.TabIndex = 8;
            this.lbUsername1.Text = "Not read yet";
            // 
            // lbUsername2
            // 
            this.lbUsername2.Location = new System.Drawing.Point(149, 110);
            this.lbUsername2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername2.Name = "lbUsername2";
            this.lbUsername2.Size = new System.Drawing.Size(184, 16);
            this.lbUsername2.TabIndex = 12;
            this.lbUsername2.Text = "Not read yet";
            // 
            // blUsn2
            // 
            this.blUsn2.AutoSize = true;
            this.blUsn2.Location = new System.Drawing.Point(48, 110);
            this.blUsn2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn2.Name = "blUsn2";
            this.blUsn2.Size = new System.Drawing.Size(93, 17);
            this.blUsn2.TabIndex = 11;
            this.blUsn2.Text = "Username 2 :";
            // 
            // tbPSNId2
            // 
            this.tbPSNId2.Location = new System.Drawing.Point(341, 106);
            this.tbPSNId2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId2.Name = "tbPSNId2";
            this.tbPSNId2.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId2.TabIndex = 10;
            // 
            // btSetAccountId2
            // 
            this.btSetAccountId2.Enabled = false;
            this.btSetAccountId2.Location = new System.Drawing.Point(648, 103);
            this.btSetAccountId2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId2.Name = "btSetAccountId2";
            this.btSetAccountId2.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId2.TabIndex = 9;
            this.btSetAccountId2.Text = "3. Set Id && Activate";
            this.btSetAccountId2.UseVisualStyleBackColor = true;
            this.btSetAccountId2.Click += new System.EventHandler(this.btSetAccountId2_Click);
            // 
            // lbUsername3
            // 
            this.lbUsername3.Location = new System.Drawing.Point(149, 142);
            this.lbUsername3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername3.Name = "lbUsername3";
            this.lbUsername3.Size = new System.Drawing.Size(184, 16);
            this.lbUsername3.TabIndex = 16;
            this.lbUsername3.Text = "Not read yet";
            // 
            // blUsn3
            // 
            this.blUsn3.AutoSize = true;
            this.blUsn3.Location = new System.Drawing.Point(48, 142);
            this.blUsn3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn3.Name = "blUsn3";
            this.blUsn3.Size = new System.Drawing.Size(93, 17);
            this.blUsn3.TabIndex = 15;
            this.blUsn3.Text = "Username 3 :";
            // 
            // tbPSNId3
            // 
            this.tbPSNId3.Location = new System.Drawing.Point(341, 138);
            this.tbPSNId3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId3.Name = "tbPSNId3";
            this.tbPSNId3.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId3.TabIndex = 14;
            // 
            // btSetAccountId3
            // 
            this.btSetAccountId3.Enabled = false;
            this.btSetAccountId3.Location = new System.Drawing.Point(648, 135);
            this.btSetAccountId3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId3.Name = "btSetAccountId3";
            this.btSetAccountId3.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId3.TabIndex = 13;
            this.btSetAccountId3.Text = "3. Set Id && Activate";
            this.btSetAccountId3.UseVisualStyleBackColor = true;
            this.btSetAccountId3.Click += new System.EventHandler(this.btSetAccountId3_Click);
            // 
            // lbUsername4
            // 
            this.lbUsername4.Location = new System.Drawing.Point(149, 174);
            this.lbUsername4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername4.Name = "lbUsername4";
            this.lbUsername4.Size = new System.Drawing.Size(184, 16);
            this.lbUsername4.TabIndex = 20;
            this.lbUsername4.Text = "Not read yet";
            // 
            // blUsn4
            // 
            this.blUsn4.AutoSize = true;
            this.blUsn4.Location = new System.Drawing.Point(48, 174);
            this.blUsn4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn4.Name = "blUsn4";
            this.blUsn4.Size = new System.Drawing.Size(93, 17);
            this.blUsn4.TabIndex = 19;
            this.blUsn4.Text = "Username 4 :";
            // 
            // tbPSNId4
            // 
            this.tbPSNId4.Location = new System.Drawing.Point(341, 170);
            this.tbPSNId4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId4.Name = "tbPSNId4";
            this.tbPSNId4.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId4.TabIndex = 18;
            // 
            // btSetAccountId4
            // 
            this.btSetAccountId4.Enabled = false;
            this.btSetAccountId4.Location = new System.Drawing.Point(648, 167);
            this.btSetAccountId4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId4.Name = "btSetAccountId4";
            this.btSetAccountId4.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId4.TabIndex = 17;
            this.btSetAccountId4.Text = "3. Set Id && Activate";
            this.btSetAccountId4.UseVisualStyleBackColor = true;
            this.btSetAccountId4.Click += new System.EventHandler(this.btSetAccountId4_Click);
            // 
            // lbUsername5
            // 
            this.lbUsername5.Location = new System.Drawing.Point(149, 206);
            this.lbUsername5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername5.Name = "lbUsername5";
            this.lbUsername5.Size = new System.Drawing.Size(184, 16);
            this.lbUsername5.TabIndex = 24;
            this.lbUsername5.Text = "Not read yet";
            // 
            // blUsn5
            // 
            this.blUsn5.AutoSize = true;
            this.blUsn5.Location = new System.Drawing.Point(48, 206);
            this.blUsn5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn5.Name = "blUsn5";
            this.blUsn5.Size = new System.Drawing.Size(93, 17);
            this.blUsn5.TabIndex = 23;
            this.blUsn5.Text = "Username 5 :";
            // 
            // tbPSNId5
            // 
            this.tbPSNId5.Location = new System.Drawing.Point(341, 202);
            this.tbPSNId5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId5.Name = "tbPSNId5";
            this.tbPSNId5.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId5.TabIndex = 22;
            // 
            // btSetAccountId5
            // 
            this.btSetAccountId5.Enabled = false;
            this.btSetAccountId5.Location = new System.Drawing.Point(648, 199);
            this.btSetAccountId5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId5.Name = "btSetAccountId5";
            this.btSetAccountId5.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId5.TabIndex = 21;
            this.btSetAccountId5.Text = "3. Set Id && Activate";
            this.btSetAccountId5.UseVisualStyleBackColor = true;
            this.btSetAccountId5.Click += new System.EventHandler(this.btSetAccountId5_Click);
            // 
            // lbUsername6
            // 
            this.lbUsername6.Location = new System.Drawing.Point(149, 238);
            this.lbUsername6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername6.Name = "lbUsername6";
            this.lbUsername6.Size = new System.Drawing.Size(184, 16);
            this.lbUsername6.TabIndex = 28;
            this.lbUsername6.Text = "Not read yet";
            // 
            // blUsn6
            // 
            this.blUsn6.AutoSize = true;
            this.blUsn6.Location = new System.Drawing.Point(48, 238);
            this.blUsn6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn6.Name = "blUsn6";
            this.blUsn6.Size = new System.Drawing.Size(93, 17);
            this.blUsn6.TabIndex = 27;
            this.blUsn6.Text = "Username 6 :";
            // 
            // tbPSNId6
            // 
            this.tbPSNId6.Location = new System.Drawing.Point(341, 234);
            this.tbPSNId6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId6.Name = "tbPSNId6";
            this.tbPSNId6.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId6.TabIndex = 26;
            // 
            // btSetAccountId6
            // 
            this.btSetAccountId6.Enabled = false;
            this.btSetAccountId6.Location = new System.Drawing.Point(648, 231);
            this.btSetAccountId6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId6.Name = "btSetAccountId6";
            this.btSetAccountId6.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId6.TabIndex = 25;
            this.btSetAccountId6.Text = "3. Set Id && Activate";
            this.btSetAccountId6.UseVisualStyleBackColor = true;
            this.btSetAccountId6.Click += new System.EventHandler(this.btSetAccountId6_Click);
            // 
            // lbUsername7
            // 
            this.lbUsername7.Location = new System.Drawing.Point(149, 270);
            this.lbUsername7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername7.Name = "lbUsername7";
            this.lbUsername7.Size = new System.Drawing.Size(184, 16);
            this.lbUsername7.TabIndex = 32;
            this.lbUsername7.Text = "Not read yet";
            // 
            // blUsn7
            // 
            this.blUsn7.AutoSize = true;
            this.blUsn7.Location = new System.Drawing.Point(48, 270);
            this.blUsn7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn7.Name = "blUsn7";
            this.blUsn7.Size = new System.Drawing.Size(93, 17);
            this.blUsn7.TabIndex = 31;
            this.blUsn7.Text = "Username 7 :";
            // 
            // tbPSNId7
            // 
            this.tbPSNId7.Location = new System.Drawing.Point(341, 266);
            this.tbPSNId7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId7.Name = "tbPSNId7";
            this.tbPSNId7.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId7.TabIndex = 30;
            // 
            // btSetAccountId7
            // 
            this.btSetAccountId7.Enabled = false;
            this.btSetAccountId7.Location = new System.Drawing.Point(648, 263);
            this.btSetAccountId7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId7.Name = "btSetAccountId7";
            this.btSetAccountId7.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId7.TabIndex = 29;
            this.btSetAccountId7.Text = "3. Set Id && Activate";
            this.btSetAccountId7.UseVisualStyleBackColor = true;
            this.btSetAccountId7.Click += new System.EventHandler(this.btSetAccountId7_Click);
            // 
            // lbUsername8
            // 
            this.lbUsername8.Location = new System.Drawing.Point(149, 302);
            this.lbUsername8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername8.Name = "lbUsername8";
            this.lbUsername8.Size = new System.Drawing.Size(184, 16);
            this.lbUsername8.TabIndex = 36;
            this.lbUsername8.Text = "Not read yet";
            // 
            // blUsn8
            // 
            this.blUsn8.AutoSize = true;
            this.blUsn8.Location = new System.Drawing.Point(48, 302);
            this.blUsn8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn8.Name = "blUsn8";
            this.blUsn8.Size = new System.Drawing.Size(93, 17);
            this.blUsn8.TabIndex = 35;
            this.blUsn8.Text = "Username 8 :";
            // 
            // tbPSNId8
            // 
            this.tbPSNId8.Location = new System.Drawing.Point(341, 298);
            this.tbPSNId8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId8.Name = "tbPSNId8";
            this.tbPSNId8.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId8.TabIndex = 34;
            // 
            // btSetAccountId8
            // 
            this.btSetAccountId8.Enabled = false;
            this.btSetAccountId8.Location = new System.Drawing.Point(648, 295);
            this.btSetAccountId8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId8.Name = "btSetAccountId8";
            this.btSetAccountId8.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId8.TabIndex = 33;
            this.btSetAccountId8.Text = "3. Set Id && Activate";
            this.btSetAccountId8.UseVisualStyleBackColor = true;
            this.btSetAccountId8.Click += new System.EventHandler(this.btSetAccountId8_Click);
            // 
            // lbUsername9
            // 
            this.lbUsername9.Location = new System.Drawing.Point(149, 334);
            this.lbUsername9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername9.Name = "lbUsername9";
            this.lbUsername9.Size = new System.Drawing.Size(184, 16);
            this.lbUsername9.TabIndex = 40;
            this.lbUsername9.Text = "Not read yet";
            // 
            // blUsn9
            // 
            this.blUsn9.AutoSize = true;
            this.blUsn9.Location = new System.Drawing.Point(48, 334);
            this.blUsn9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn9.Name = "blUsn9";
            this.blUsn9.Size = new System.Drawing.Size(93, 17);
            this.blUsn9.TabIndex = 39;
            this.blUsn9.Text = "Username 9 :";
            // 
            // tbPSNId9
            // 
            this.tbPSNId9.Location = new System.Drawing.Point(341, 330);
            this.tbPSNId9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId9.Name = "tbPSNId9";
            this.tbPSNId9.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId9.TabIndex = 38;
            // 
            // btSetAccountId9
            // 
            this.btSetAccountId9.Enabled = false;
            this.btSetAccountId9.Location = new System.Drawing.Point(648, 327);
            this.btSetAccountId9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId9.Name = "btSetAccountId9";
            this.btSetAccountId9.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId9.TabIndex = 37;
            this.btSetAccountId9.Text = "3. Set Id && Activate";
            this.btSetAccountId9.UseVisualStyleBackColor = true;
            this.btSetAccountId9.Click += new System.EventHandler(this.btSetAccountId9_Click);
            // 
            // lbUsername10
            // 
            this.lbUsername10.Location = new System.Drawing.Point(149, 366);
            this.lbUsername10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername10.Name = "lbUsername10";
            this.lbUsername10.Size = new System.Drawing.Size(184, 16);
            this.lbUsername10.TabIndex = 44;
            this.lbUsername10.Text = "Not read yet";
            // 
            // blUsn10
            // 
            this.blUsn10.AutoSize = true;
            this.blUsn10.Location = new System.Drawing.Point(48, 366);
            this.blUsn10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn10.Name = "blUsn10";
            this.blUsn10.Size = new System.Drawing.Size(101, 17);
            this.blUsn10.TabIndex = 43;
            this.blUsn10.Text = "Username 10 :";
            // 
            // tbPSNId10
            // 
            this.tbPSNId10.Location = new System.Drawing.Point(341, 362);
            this.tbPSNId10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId10.Name = "tbPSNId10";
            this.tbPSNId10.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId10.TabIndex = 42;
            // 
            // btSetAccountId10
            // 
            this.btSetAccountId10.Enabled = false;
            this.btSetAccountId10.Location = new System.Drawing.Point(648, 359);
            this.btSetAccountId10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId10.Name = "btSetAccountId10";
            this.btSetAccountId10.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId10.TabIndex = 41;
            this.btSetAccountId10.Text = "3. Set Id && Activate";
            this.btSetAccountId10.UseVisualStyleBackColor = true;
            this.btSetAccountId10.Click += new System.EventHandler(this.btSetAccountId10_Click);
            // 
            // lbUsername11
            // 
            this.lbUsername11.Location = new System.Drawing.Point(149, 398);
            this.lbUsername11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername11.Name = "lbUsername11";
            this.lbUsername11.Size = new System.Drawing.Size(184, 16);
            this.lbUsername11.TabIndex = 48;
            this.lbUsername11.Text = "Not read yet";
            // 
            // blUsn11
            // 
            this.blUsn11.AutoSize = true;
            this.blUsn11.Location = new System.Drawing.Point(48, 398);
            this.blUsn11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn11.Name = "blUsn11";
            this.blUsn11.Size = new System.Drawing.Size(101, 17);
            this.blUsn11.TabIndex = 47;
            this.blUsn11.Text = "Username 11 :";
            // 
            // tbPSNId11
            // 
            this.tbPSNId11.Location = new System.Drawing.Point(341, 394);
            this.tbPSNId11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId11.Name = "tbPSNId11";
            this.tbPSNId11.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId11.TabIndex = 46;
            // 
            // btSetAccountId11
            // 
            this.btSetAccountId11.Enabled = false;
            this.btSetAccountId11.Location = new System.Drawing.Point(648, 391);
            this.btSetAccountId11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId11.Name = "btSetAccountId11";
            this.btSetAccountId11.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId11.TabIndex = 45;
            this.btSetAccountId11.Text = "3. Set Id && Activate";
            this.btSetAccountId11.UseVisualStyleBackColor = true;
            this.btSetAccountId11.Click += new System.EventHandler(this.btSetAccountId11_Click);
            // 
            // lbUsername12
            // 
            this.lbUsername12.Location = new System.Drawing.Point(149, 430);
            this.lbUsername12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername12.Name = "lbUsername12";
            this.lbUsername12.Size = new System.Drawing.Size(184, 16);
            this.lbUsername12.TabIndex = 52;
            this.lbUsername12.Text = "Not read yet";
            // 
            // blUsn12
            // 
            this.blUsn12.AutoSize = true;
            this.blUsn12.Location = new System.Drawing.Point(48, 430);
            this.blUsn12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn12.Name = "blUsn12";
            this.blUsn12.Size = new System.Drawing.Size(101, 17);
            this.blUsn12.TabIndex = 51;
            this.blUsn12.Text = "Username 12 :";
            // 
            // tbPSNId12
            // 
            this.tbPSNId12.Location = new System.Drawing.Point(341, 426);
            this.tbPSNId12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId12.Name = "tbPSNId12";
            this.tbPSNId12.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId12.TabIndex = 50;
            // 
            // btSetAccountId12
            // 
            this.btSetAccountId12.Enabled = false;
            this.btSetAccountId12.Location = new System.Drawing.Point(648, 423);
            this.btSetAccountId12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId12.Name = "btSetAccountId12";
            this.btSetAccountId12.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId12.TabIndex = 49;
            this.btSetAccountId12.Text = "3. Set Id && Activate";
            this.btSetAccountId12.UseVisualStyleBackColor = true;
            this.btSetAccountId12.Click += new System.EventHandler(this.btSetAccountId12_Click);
            // 
            // lbUsername13
            // 
            this.lbUsername13.Location = new System.Drawing.Point(149, 462);
            this.lbUsername13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername13.Name = "lbUsername13";
            this.lbUsername13.Size = new System.Drawing.Size(184, 16);
            this.lbUsername13.TabIndex = 56;
            this.lbUsername13.Text = "Not read yet";
            // 
            // blUsn13
            // 
            this.blUsn13.AutoSize = true;
            this.blUsn13.Location = new System.Drawing.Point(48, 462);
            this.blUsn13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn13.Name = "blUsn13";
            this.blUsn13.Size = new System.Drawing.Size(101, 17);
            this.blUsn13.TabIndex = 55;
            this.blUsn13.Text = "Username 13 :";
            // 
            // tbPSNId13
            // 
            this.tbPSNId13.Location = new System.Drawing.Point(341, 458);
            this.tbPSNId13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId13.Name = "tbPSNId13";
            this.tbPSNId13.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId13.TabIndex = 54;
            // 
            // btSetAccountId13
            // 
            this.btSetAccountId13.Enabled = false;
            this.btSetAccountId13.Location = new System.Drawing.Point(648, 455);
            this.btSetAccountId13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId13.Name = "btSetAccountId13";
            this.btSetAccountId13.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId13.TabIndex = 53;
            this.btSetAccountId13.Text = "3. Set Id && Activate";
            this.btSetAccountId13.UseVisualStyleBackColor = true;
            this.btSetAccountId13.Click += new System.EventHandler(this.btSetAccountId13_Click);
            // 
            // lbUsername14
            // 
            this.lbUsername14.Location = new System.Drawing.Point(149, 494);
            this.lbUsername14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername14.Name = "lbUsername14";
            this.lbUsername14.Size = new System.Drawing.Size(184, 16);
            this.lbUsername14.TabIndex = 60;
            this.lbUsername14.Text = "Not read yet";
            // 
            // blUsn14
            // 
            this.blUsn14.AutoSize = true;
            this.blUsn14.Location = new System.Drawing.Point(48, 494);
            this.blUsn14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn14.Name = "blUsn14";
            this.blUsn14.Size = new System.Drawing.Size(101, 17);
            this.blUsn14.TabIndex = 59;
            this.blUsn14.Text = "Username 14 :";
            // 
            // tbPSNId14
            // 
            this.tbPSNId14.Location = new System.Drawing.Point(341, 490);
            this.tbPSNId14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId14.Name = "tbPSNId14";
            this.tbPSNId14.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId14.TabIndex = 58;
            // 
            // btSetAccountId14
            // 
            this.btSetAccountId14.Enabled = false;
            this.btSetAccountId14.Location = new System.Drawing.Point(648, 487);
            this.btSetAccountId14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId14.Name = "btSetAccountId14";
            this.btSetAccountId14.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId14.TabIndex = 57;
            this.btSetAccountId14.Text = "3. Set Id && Activate";
            this.btSetAccountId14.UseVisualStyleBackColor = true;
            this.btSetAccountId14.Click += new System.EventHandler(this.btSetAccountId14_Click);
            // 
            // lbUsername15
            // 
            this.lbUsername15.Location = new System.Drawing.Point(149, 526);
            this.lbUsername15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername15.Name = "lbUsername15";
            this.lbUsername15.Size = new System.Drawing.Size(184, 16);
            this.lbUsername15.TabIndex = 64;
            this.lbUsername15.Text = "Not read yet";
            // 
            // blUsn15
            // 
            this.blUsn15.AutoSize = true;
            this.blUsn15.Location = new System.Drawing.Point(48, 526);
            this.blUsn15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn15.Name = "blUsn15";
            this.blUsn15.Size = new System.Drawing.Size(101, 17);
            this.blUsn15.TabIndex = 63;
            this.blUsn15.Text = "Username 15 :";
            // 
            // tbPSNId15
            // 
            this.tbPSNId15.Location = new System.Drawing.Point(341, 522);
            this.tbPSNId15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId15.Name = "tbPSNId15";
            this.tbPSNId15.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId15.TabIndex = 62;
            // 
            // btSetAccountId15
            // 
            this.btSetAccountId15.Enabled = false;
            this.btSetAccountId15.Location = new System.Drawing.Point(648, 519);
            this.btSetAccountId15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId15.Name = "btSetAccountId15";
            this.btSetAccountId15.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId15.TabIndex = 61;
            this.btSetAccountId15.Text = "3. Set Id && Activate";
            this.btSetAccountId15.UseVisualStyleBackColor = true;
            this.btSetAccountId15.Click += new System.EventHandler(this.btSetAccountId15_Click);
            // 
            // lbUsername16
            // 
            this.lbUsername16.Location = new System.Drawing.Point(149, 558);
            this.lbUsername16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsername16.Name = "lbUsername16";
            this.lbUsername16.Size = new System.Drawing.Size(184, 16);
            this.lbUsername16.TabIndex = 68;
            this.lbUsername16.Text = "Not read yet";
            // 
            // blUsn16
            // 
            this.blUsn16.AutoSize = true;
            this.blUsn16.Location = new System.Drawing.Point(48, 558);
            this.blUsn16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.blUsn16.Name = "blUsn16";
            this.blUsn16.Size = new System.Drawing.Size(101, 17);
            this.blUsn16.TabIndex = 67;
            this.blUsn16.Text = "Username 16 :";
            // 
            // tbPSNId16
            // 
            this.tbPSNId16.Location = new System.Drawing.Point(341, 554);
            this.tbPSNId16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPSNId16.Name = "tbPSNId16";
            this.tbPSNId16.Size = new System.Drawing.Size(297, 22);
            this.tbPSNId16.TabIndex = 66;
            // 
            // btSetAccountId16
            // 
            this.btSetAccountId16.Enabled = false;
            this.btSetAccountId16.Location = new System.Drawing.Point(648, 551);
            this.btSetAccountId16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSetAccountId16.Name = "btSetAccountId16";
            this.btSetAccountId16.Size = new System.Drawing.Size(160, 28);
            this.btSetAccountId16.TabIndex = 65;
            this.btSetAccountId16.Text = "3. Set Id && Activate";
            this.btSetAccountId16.UseVisualStyleBackColor = true;
            this.btSetAccountId16.Click += new System.EventHandler(this.btSetAccountId16_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 635);
            this.Controls.Add(this.lbUsername16);
            this.Controls.Add(this.blUsn16);
            this.Controls.Add(this.tbPSNId16);
            this.Controls.Add(this.btSetAccountId16);
            this.Controls.Add(this.lbUsername15);
            this.Controls.Add(this.blUsn15);
            this.Controls.Add(this.tbPSNId15);
            this.Controls.Add(this.btSetAccountId15);
            this.Controls.Add(this.lbUsername14);
            this.Controls.Add(this.blUsn14);
            this.Controls.Add(this.tbPSNId14);
            this.Controls.Add(this.btSetAccountId14);
            this.Controls.Add(this.lbUsername13);
            this.Controls.Add(this.blUsn13);
            this.Controls.Add(this.tbPSNId13);
            this.Controls.Add(this.btSetAccountId13);
            this.Controls.Add(this.lbUsername12);
            this.Controls.Add(this.blUsn12);
            this.Controls.Add(this.tbPSNId12);
            this.Controls.Add(this.btSetAccountId12);
            this.Controls.Add(this.lbUsername11);
            this.Controls.Add(this.blUsn11);
            this.Controls.Add(this.tbPSNId11);
            this.Controls.Add(this.btSetAccountId11);
            this.Controls.Add(this.lbUsername10);
            this.Controls.Add(this.blUsn10);
            this.Controls.Add(this.tbPSNId10);
            this.Controls.Add(this.btSetAccountId10);
            this.Controls.Add(this.lbUsername9);
            this.Controls.Add(this.blUsn9);
            this.Controls.Add(this.tbPSNId9);
            this.Controls.Add(this.btSetAccountId9);
            this.Controls.Add(this.lbUsername8);
            this.Controls.Add(this.blUsn8);
            this.Controls.Add(this.tbPSNId8);
            this.Controls.Add(this.btSetAccountId8);
            this.Controls.Add(this.lbUsername7);
            this.Controls.Add(this.blUsn7);
            this.Controls.Add(this.tbPSNId7);
            this.Controls.Add(this.btSetAccountId7);
            this.Controls.Add(this.lbUsername6);
            this.Controls.Add(this.blUsn6);
            this.Controls.Add(this.tbPSNId6);
            this.Controls.Add(this.btSetAccountId6);
            this.Controls.Add(this.lbUsername5);
            this.Controls.Add(this.blUsn5);
            this.Controls.Add(this.tbPSNId5);
            this.Controls.Add(this.btSetAccountId5);
            this.Controls.Add(this.lbUsername4);
            this.Controls.Add(this.blUsn4);
            this.Controls.Add(this.tbPSNId4);
            this.Controls.Add(this.btSetAccountId4);
            this.Controls.Add(this.lbUsername3);
            this.Controls.Add(this.blUsn3);
            this.Controls.Add(this.tbPSNId3);
            this.Controls.Add(this.btSetAccountId3);
            this.Controls.Add(this.lbUsername2);
            this.Controls.Add(this.blUsn2);
            this.Controls.Add(this.tbPSNId2);
            this.Controls.Add(this.btSetAccountId2);
            this.Controls.Add(this.lbUsername1);
            this.Controls.Add(this.blUsn1);
            this.Controls.Add(this.tbPSNId1);
            this.Controls.Add(this.btSetAccountId1);
            this.Controls.Add(this.btGetUsers);
            this.Controls.Add(this.lbIPAddress);
            this.Controls.Add(this.tbIPAddress);
            this.Controls.Add(this.btConnect);
            this.Controls.Add(this.statusStrip1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainForm";
            this.Text = "PS4 Offline Account Activator by barthen";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button btConnect;
        private System.Windows.Forms.TextBox tbIPAddress;
        private System.Windows.Forms.Label lbIPAddress;
        private System.Windows.Forms.Button btGetUsers;
        private System.Windows.Forms.Label blUsn1;
        private System.Windows.Forms.TextBox tbPSNId1;
        private System.Windows.Forms.Button btSetAccountId1;
        private System.Windows.Forms.Label lbUsername1;
        private System.Windows.Forms.Label lbUsername2;
        private System.Windows.Forms.Label blUsn2;
        private System.Windows.Forms.TextBox tbPSNId2;
        private System.Windows.Forms.Button btSetAccountId2;
        private System.Windows.Forms.Label lbUsername3;
        private System.Windows.Forms.Label blUsn3;
        private System.Windows.Forms.TextBox tbPSNId3;
        private System.Windows.Forms.Button btSetAccountId3;
        private System.Windows.Forms.Label lbUsername4;
        private System.Windows.Forms.Label blUsn4;
        private System.Windows.Forms.TextBox tbPSNId4;
        private System.Windows.Forms.Button btSetAccountId4;
        private System.Windows.Forms.Label lbUsername5;
        private System.Windows.Forms.Label blUsn5;
        private System.Windows.Forms.TextBox tbPSNId5;
        private System.Windows.Forms.Button btSetAccountId5;
        private System.Windows.Forms.Label lbUsername6;
        private System.Windows.Forms.Label blUsn6;
        private System.Windows.Forms.TextBox tbPSNId6;
        private System.Windows.Forms.Button btSetAccountId6;
        private System.Windows.Forms.Label lbUsername7;
        private System.Windows.Forms.Label blUsn7;
        private System.Windows.Forms.TextBox tbPSNId7;
        private System.Windows.Forms.Button btSetAccountId7;
        private System.Windows.Forms.Label lbUsername8;
        private System.Windows.Forms.Label blUsn8;
        private System.Windows.Forms.TextBox tbPSNId8;
        private System.Windows.Forms.Button btSetAccountId8;
        private System.Windows.Forms.Label lbUsername9;
        private System.Windows.Forms.Label blUsn9;
        private System.Windows.Forms.TextBox tbPSNId9;
        private System.Windows.Forms.Button btSetAccountId9;
        private System.Windows.Forms.Label lbUsername10;
        private System.Windows.Forms.Label blUsn10;
        private System.Windows.Forms.TextBox tbPSNId10;
        private System.Windows.Forms.Button btSetAccountId10;
        private System.Windows.Forms.Label lbUsername11;
        private System.Windows.Forms.Label blUsn11;
        private System.Windows.Forms.TextBox tbPSNId11;
        private System.Windows.Forms.Button btSetAccountId11;
        private System.Windows.Forms.Label lbUsername12;
        private System.Windows.Forms.Label blUsn12;
        private System.Windows.Forms.TextBox tbPSNId12;
        private System.Windows.Forms.Button btSetAccountId12;
        private System.Windows.Forms.Label lbUsername13;
        private System.Windows.Forms.Label blUsn13;
        private System.Windows.Forms.TextBox tbPSNId13;
        private System.Windows.Forms.Button btSetAccountId13;
        private System.Windows.Forms.Label lbUsername14;
        private System.Windows.Forms.Label blUsn14;
        private System.Windows.Forms.TextBox tbPSNId14;
        private System.Windows.Forms.Button btSetAccountId14;
        private System.Windows.Forms.Label lbUsername15;
        private System.Windows.Forms.Label blUsn15;
        private System.Windows.Forms.TextBox tbPSNId15;
        private System.Windows.Forms.Button btSetAccountId15;
        private System.Windows.Forms.Label lbUsername16;
        private System.Windows.Forms.Label blUsn16;
        private System.Windows.Forms.TextBox tbPSNId16;
        private System.Windows.Forms.Button btSetAccountId16;
    }
}

